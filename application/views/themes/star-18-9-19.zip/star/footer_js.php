<script type='text/javascript' src="<?php echo media_url('footer.js'); ?>"></script>
<?php echo get_option('google_analytics_js'); ?>