<section class="clients-section">
    <div class="auto-container">
        <div class="sponsors-outer">
            <!--Sponsors Carousel-->
            <ul class="sponsors-carousel owl-carousel owl-theme">
                <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo media_url('images/clients/1-1.png'); ?>" alt=""></a></figure></li>
                <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo media_url('images/clients/1-2.png'); ?>" alt=""></a></figure></li>
                <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo media_url('images/clients/1-3.png'); ?>" alt=""></a></figure></li>
                <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo media_url('images/clients/1-4.png'); ?>" alt=""></a></figure></li>
                <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo media_url('images/clients/1-1.png'); ?>" alt=""></a></figure></li>
                <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo media_url('images/clients/1-2.png'); ?>" alt=""></a></figure></li>
                <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo media_url('images/clients/1-3.png'); ?>" alt=""></a></figure></li>
                <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo media_url('images/clients/1-4.png'); ?>" alt=""></a></figure></li>
            </ul>
        </div>
    </div>
</section>