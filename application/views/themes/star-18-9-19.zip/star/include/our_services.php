<div class="vc_row wpb_row vc_row-fluid vc_row-o-content-middle vc_row-flex">
                                       <div class="wpb_column vc_column_container vc_col-sm-5">
                                           <div class="vc_column-inner vc_custom_1515054926354">
                                               <div class="wpb_wrapper">
                                                   <div class="wpb_single_image wpb_content_element vc_align_left">
                                                       <figure class="wpb_wrapper vc_figure">
                                                           <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="470" height="749" src="images/img-01.png" class="vc_single_image-img attachment-full" alt="" srcset="http://themes.g5plus.net/benaa/wp-content/uploads/2018/01/img-01.png 470w, http://themes.g5plus.net/benaa/wp-content/uploads/2018/01/img-01-188x300.png 188w" sizes="(max-width: 470px) 100vw, 470px" /></div>
                                                       </figure>
                                                   </div>
                                               </div>
                                           </div>
                                       </div>
                                       <div class="wpb_column vc_column_container vc_col-sm-7">
                                           <div class="vc_column-inner vc_custom_1515057413148">
                                               <div class="wpb_wrapper">
                                                   <div class="g5plus-heading style1 text-left color-dark vc_custom_1515055218634"> <i class="icon-house-roof2"></i>
                                                       <h2>OUR SERVICES</h2>
                                                       <p>WHAT WE DO FOR YOU</p>
                                                   </div>
                                                   <div class="wpb_text_column wpb_content_element  vc_custom_1515055254459">
                                                       <div class="wpb_wrapper">
                                                           <p>Temporibus autem quibusdam et aut officiis debitis is aut rerum necessitatibus saepes eveniet ut etes seo lage voluptates repudiandae sint et molestiae non mes for Creating futures through building pres preservation.</p>
                                                       </div>
                                                   </div>
                                                   <div class="g5plus-icon-box layout-left color-dark shape-bg-white-outline-circle">
                                                       <div class="icon-wrap"> <i class="icon-house"></i></div>
                                                       <div class="info-wrap">
                                                           <h6>Renting and Selling Services</h6>
                                                           <p>Lorem ipsum dolor sit , consectet adipisi elit, sed do eiusmod consectet adipisi elit, sed do eiusmod tempor for enim consectet adipisi elit, sed do consectet adipisi elit, sedes doadesg ens minim veniam.</p>
                                                       </div>
                                                   </div>
                                                   <div class="g5plus-icon-box layout-left color-dark shape-bg-white-outline-circle">
                                                       <div class="icon-wrap"> <i class="icon-wrench2"></i></div>
                                                       <div class="info-wrap">
                                                           <h6>Property Management</h6>
                                                           <p>Lorem ipsum dolor sit , consectet adipisi elit, sed do eiusmod consectet adipisi elit, sed do eiusmod tempor for enim consectet adipisi elit, sed do consectet adipisi elit, sedes doadesg ens minim veniam.</p>
                                                       </div>
                                                   </div>
                                                   <div class="g5plus-icon-box layout-left color-dark shape-bg-white-outline-circle">
                                                       <div class="icon-wrap"> <i class="icon-building"></i></div>
                                                       <div class="info-wrap">
                                                           <h6>Property Listing</h6>
                                                           <p>Lorem ipsum dolor sit , consectet adipisi elit, sed do eiusmod consectet adipisi elit, sed do eiusmod tempor for enim consectet adipisi elit, sed do consectet adipisi elit, sedes doadesg ens minim veniam.</p>
                                                       </div>
                                                   </div>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
