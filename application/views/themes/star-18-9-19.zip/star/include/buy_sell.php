<?php echo $this->cms->get_block('sell-buy');?>
<!--<div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-parallax="1.5"
        data-vc-parallax-image="<?php /*echo media_url('/images/background-2.jpg'); */?>"
        class="vc_row wpb_row vc_row-fluid vc_row-has-fill vc_general vc_parallax vc_parallax-content-moving vc_row-background-overlay-wrap">
    <div class="vc_row-background-overlay" style="background-color: rgba(0,0,0,0.7)"></div>
    <div class="text-center wpb_column vc_column_container vc_col-sm-8 vc_col-sm-offset-2">
        <div class="vc_column-inner">
            <div class="wpb_wrapper">
                <div class="g5plus-space space-5cec5e37bb5d9" data-id="5cec5e37bb5d9" data-tablet="70"
                        data-tablet-portrait="50" data-mobile="40" data-mobile-landscape="40"
                        style="clear: both; display: block; height: 90px"></div>
                <div class="wpb_text_column wpb_content_element  vc_custom_1515048249533">
                    <div class="wpb_wrapper">
                        <h2 class="fs-48 fw-medium text-center"><span style="color: #ffffff;">Buy or sell your <span
                                        class="accent-color">house</span> in few seconds with benaa</span></h2></div>
                </div>
                <div class="g5plus-btn-container btn-inline vc_custom_1515059301462"><a
                            class="btn btn-lg btn-primary btn-classic btn-shape-round" href="<?php /*echo site_url('property/add');*/?>"
                            target="_blank">SUBMIT PROPERTY</a></div>
                <div class="g5plus-btn-container btn-inline vc_custom_1515059305479"><a
                            class="btn btn-lg btn-primary btn-outline btn-shape-round" href="<?php /*echo site_url('property');*/?>"
                            target="_blank">BROWSE PROPERTIES</a></div>
                <div class="g5plus-space space-5cec5e37bbf93" data-id="5cec5e37bbf93" data-tablet="60"
                        data-tablet-portrait="40" data-mobile="20" data-mobile-landscape="20"
                        style="clear: both; display: block; height: 80px"></div>
            </div>
        </div>
    </div>
</div>
<div class="vc_row-full-width vc_clearfix"></div>-->